plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{
namespace="com.jarvis.assistant";compileSdk=34
signingConfigs{getByName("debug"){storeFile=file("debug.keystore");storeType="pkcs12";storePassword="android";keyAlias="androiddebugkey";keyPassword="android"}}
defaultConfig{applicationId="com.jarvis.assistant";minSdk=26;targetSdk=34;versionCode=5;versionName="1.5"}
compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
kotlinOptions{jvmTarget="17"}
}
