package com.jarvis.assistant
import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.*
import android.widget.EditText
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

open class MainActivity : Activity() {
    open val overlay: Boolean = false
    private lateinit var web: WebView
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var loaded = false
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    private fun js(s: String) = runOnUiThread { web.evaluateJavascript(s, null) }
    private fun q(s: String) = JSONObject.quote(s)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA), 1)
        tts = TextToSpeech(this) { ttsReady = it == TextToSpeech.SUCCESS; if (ttsReady) { tts?.language = Locale("tr", "TR"); tts?.setPitch(0.78f); tts?.setSpeechRate(0.92f); setupFx(); applyVoice(prefs.getInt("voice", 0)) } }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) { js("__tts('start',$u)") }
            override fun onDone(u: String?) { js("__tts('end',$u)"); closeSoon(2500) }
            override fun onError(u: String?) { js("__tts('end',$u)") }
            override fun onStop(u: String?, i: Boolean) { js("__tts('end',$u)") }
        })
        web = WebView(this)
        if (overlay) {
            web.setBackgroundColor(0)
            val root = android.widget.FrameLayout(this)
            root.setOnClickListener { finish() }
            val h = (resources.displayMetrics.heightPixels * 0.42).toInt()
            root.addView(web, android.widget.FrameLayout.LayoutParams(-1, h, android.view.Gravity.BOTTOM))
            setContentView(root)
        } else {
            setContentView(web)
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) { runOnUiThread { r.grant(r.resources) } }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                startActivity(Intent(Intent.ACTION_VIEW, r.url)); return true
            }
            override fun onPageFinished(v: WebView, u: String) {
                loaded = true
                if (overlay) js("document.body.classList.add('ov')")
                autoListen()
            }
        }
        web.addJavascriptInterface(Bridge(), "J")
        val html = assets.open("index.html").bufferedReader().readText()
        web.loadDataWithBaseURL("https://jarvis.local/", html, "text/html", "utf-8", null)
    }

    private var audioSid = 0
    private val fx = mutableListOf<android.media.audiofx.AudioEffect>()

    // Sese Jarvis havası vermek için hafif bas, yumuşatılmış tiz ve küçük bir oda yankısı ekler.
    private fun setupFx() {
        audioSid = (getSystemService(AUDIO_SERVICE) as android.media.AudioManager).generateAudioSessionId()
        try { val b = android.media.audiofx.BassBoost(0, audioSid); b.setStrength(450.toShort()); b.setEnabled(true); fx.add(b) } catch (e: Exception) {}
        try { val r = android.media.audiofx.PresetReverb(0, audioSid); r.setPreset(android.media.audiofx.PresetReverb.PRESET_SMALLROOM); r.setEnabled(true); fx.add(r) } catch (e: Exception) {}
        try {
            val q = android.media.audiofx.Equalizer(0, audioSid)
            val range = q.getBandLevelRange()
            for (i in 0 until q.getNumberOfBands().toInt()) {
                val hz = q.getCenterFreq(i.toShort()) / 1000
                val lvl = if (hz < 300) range[1] / 2 else if (hz > 4000) range[0] / 3 else 0
                q.setBandLevel(i.toShort(), lvl.toShort())
            }
            q.setEnabled(true); fx.add(q)
        } catch (e: Exception) {}
    }

    private fun trVoices() = (tts?.voices ?: emptySet<android.speech.tts.Voice>())
        .filter { it.locale.language == "tr" }.sortedBy { it.name }

    private fun applyVoice(i: Int) {
        val l = trVoices()
        if (l.isNotEmpty()) tts?.voice = l[i.mod(l.size)]
    }

    // Jarvis asistan olarak seçilince sistemin varsayılan ses tanıyıcısı kendi boş tanıyıcımıza dönebiliyor.
    // Bu yüzden Google gibi gerçek bir tanıyıcıyı adıyla seçiyoruz.
    private fun recognizer(): SpeechRecognizer {
        val list = packageManager
            .queryIntentServices(Intent(android.speech.RecognitionService.SERVICE_INTERFACE), 0)
            .map { it.serviceInfo }
            .filter { it.packageName != packageName }
        val pick = list.firstOrNull { it.packageName == "com.google.android.googlequicksearchbox" }
            ?: list.firstOrNull { it.packageName.contains("google") }
            ?: list.firstOrNull()
        return if (pick != null)
            SpeechRecognizer.createSpeechRecognizer(this, android.content.ComponentName(pick.packageName, pick.name))
        else SpeechRecognizer.createSpeechRecognizer(this)
    }

    private fun closeSoon(ms: Long) {
        if (!overlay) return
        web.postDelayed({
            web.evaluateJavascript("document.getElementById('go').hidden") { if (it == "true") finish() }
        }, ms)
    }

    private fun autoListen() {
        if (loaded && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            if (overlay) js("var b=document.getElementById('bmic');if(b.getAttribute('aria-pressed')!=='true')b.click()")
            else js("var c=document.getElementById('always');if(!c.checked){c.checked=true;c.onchange({target:c})}")
    }
    override fun onNewIntent(intent: Intent?) { super.onNewIntent(intent); autoListen() }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { autoListen() }

    private fun askKey() {
        val et = EditText(this); et.hint = "sk-ant-..."
        AlertDialog.Builder(this).setTitle("Anthropic API anahtarı")
            .setMessage("Jarvis'in yapay zekâ cevapları için gerekli. Anahtar yalnızca bu telefonda saklanır.")
            .setView(et).setCancelable(false)
            .setPositiveButton("Kaydet") { _, _ -> prefs.edit().putString("key", et.text.toString().trim()).apply() }
            .setNegativeButton("Şimdi değil", null).show()
    }

    inner class Bridge {
        @JavascriptInterface fun listen(lang: String) { runOnUiThread {
            sr?.destroy()
            sr = recognizer()
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { js("__sr('start')") }
                override fun onPartialResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) js("__sr('result',${q(t)},false)")
                }
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    if (t.isBlank()) js("__sr('error','no-speech')") else js("__sr('result',${q(t)},true)")
                    js("__sr('end')")
                }
                override fun onError(e: Int) {
                    val n = when (e) { 9 -> "not-allowed"; 6, 7 -> "no-speech"; 5, 8 -> "aborted"; else -> "network" }
                    js("__sr('error','$n')"); js("__sr('end')")
                    if (overlay && (e == 6 || e == 7)) closeSoon(700)
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            sr?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true))
        } }
        @JavascriptInterface fun voices(): String = org.json.JSONArray(trVoices().map { it.name }).toString()
        @JavascriptInterface fun voiceIndex(): Int = prefs.getInt("voice", 0)
        @JavascriptInterface fun setVoice(i: Int) { prefs.edit().putInt("voice", i).apply(); applyVoice(i) }
        @JavascriptInterface fun voiceParams(p: Double, r: Double) { tts?.setPitch(p.toFloat()); tts?.setSpeechRate(r.toFloat()) }
        @JavascriptInterface fun openApp(name: String): Boolean {
            val pm = packageManager
            val n = name.lowercase(Locale("tr")).trim()
            val li = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = li.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale("tr")).contains(n) } ?: return false
            val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
            runOnUiThread { startActivity(i) }
            return true
        }
        @JavascriptInterface fun torch(on: Boolean): Boolean = try {
            val cm = getSystemService(CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            cm.setTorchMode(cm.cameraIdList[0], on); true
        } catch (e: Exception) { false }
        @JavascriptInterface fun alarm(h: Int, m: Int) { runOnUiThread { try {
            startActivity(Intent(android.provider.AlarmClock.ACTION_SET_ALARM)
                .putExtra(android.provider.AlarmClock.EXTRA_HOUR, h)
                .putExtra(android.provider.AlarmClock.EXTRA_MINUTES, m)
                .putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true))
        } catch (e: Exception) {} } }
        @JavascriptInterface fun battery(): Int =
            (getSystemService(BATTERY_SERVICE) as android.os.BatteryManager).getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        @JavascriptInterface fun volume(d: Int) {
            val a = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
            a.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                if (d > 0) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER,
                android.media.AudioManager.FLAG_SHOW_UI)
        }
        @JavascriptInterface fun nextVoice(): String {
            val l = trVoices()
            if (l.size < 2) return ""
            val i = (prefs.getInt("voice", 0) + 1) % l.size
            prefs.edit().putInt("voice", i).apply()
            applyVoice(i)
            return l[i].name
        }
        @JavascriptInterface fun screenText(): String = ScreenCtx.fresh()
        @JavascriptInterface fun stopListen() { runOnUiThread { sr?.stopListening() } }
        @JavascriptInterface fun speak(text: String, id: Int) { runOnUiThread {
            if (!ttsReady) js("__tts('end',$id)") else tts?.speak(text, TextToSpeech.QUEUE_FLUSH, if (audioSid != 0) Bundle().apply { putInt(TextToSpeech.Engine.KEY_PARAM_SESSION_ID, audioSid) } else null, id.toString())
        } }
        @JavascriptInterface fun stopSpeak() { runOnUiThread { tts?.stop() } }
        @JavascriptInterface fun hasKey(): Boolean = !prefs.getString("aikey", "").isNullOrEmpty()
        @JavascriptInterface fun setAi(provider: String, key: String, model: String) {
            prefs.edit().putString("provider", provider).putString("aikey", key.trim()).putString("model", model.trim()).apply()
        }
        @JavascriptInterface fun aiInfo(): String = JSONObject()
            .put("provider", prefs.getString("provider", "gemini")).put("key", prefs.getString("aikey", ""))
            .put("model", prefs.getString("model", "")).toString()
        @JavascriptInterface fun ask(id: Int, json: String) {
            if (prefs.getString("provider", "gemini") == "anthropic") askClaude(id, json) else askGemini(id, json)
        }

        // Anthropic biçimindeki mesajları Gemini biçimine çevirir (ilk mesaj sistem talimatı olur).
        private fun geminiBody(json: String): JSONObject {
            val msgs = JSONObject(json).getJSONArray("messages")
            val contents = org.json.JSONArray()
            for (i in 1 until msgs.length()) {
                val m = msgs.getJSONObject(i)
                val parts = org.json.JSONArray()
                val c = m.get("content")
                if (c is String) parts.put(JSONObject().put("text", c))
                else {
                    val a = c as org.json.JSONArray
                    for (j in 0 until a.length()) {
                        val b = a.getJSONObject(j)
                        if (b.getString("type") == "image") {
                            val s = b.getJSONObject("source")
                            parts.put(JSONObject().put("inline_data", JSONObject()
                                .put("mime_type", s.getString("media_type")).put("data", s.getString("data"))))
                        } else parts.put(JSONObject().put("text", b.getString("text")))
                    }
                }
                contents.put(JSONObject().put("role", if (m.getString("role") == "assistant") "model" else "user").put("parts", parts))
            }
            return JSONObject()
                .put("systemInstruction", JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", msgs.getJSONObject(0).getString("content")))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("maxOutputTokens", 1024))
        }

        private fun askGemini(id: Int, json: String) {
            Thread {
                try {
                    val body = geminiBody(json).toString().toByteArray()
                    val pref = prefs.getString("model", "")?.ifEmpty { null }
                    val models = listOfNotNull(pref) + listOf("gemini-flash-lite-latest", "gemini-flash-latest", "gemini-2.5-flash-lite", "gemini-2.5-flash")
                    var code = 0
                    var txt = ""
                    for (mdl in models) {
                        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$mdl:generateContent").openConnection() as HttpURLConnection
                        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
                        c.setRequestProperty("content-type", "application/json")
                        c.setRequestProperty("x-goog-api-key", prefs.getString("aikey", "") ?: "")
                        c.outputStream.use { it.write(body) }
                        code = c.responseCode
                        txt = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
                        if (code != 404) break
                    }
                    if (code < 400) {
                        val j = JSONObject(txt)
                        val cand = j.optJSONArray("candidates")?.optJSONObject(0)
                        val parts = cand?.optJSONObject("content")?.optJSONArray("parts")
                        val sb = StringBuilder()
                        if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                        if (sb.isBlank()) {
                            val why = cand?.optString("finishReason").orEmpty()
                                .ifEmpty { j.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty() }
                                .ifEmpty { "bos" }
                            js("__ai($id,null,${q("empty_$why")})")
                        } else js("__ai($id,${q(sb.toString())},null)")
                    } else {
                        val msg = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { "" }
                        val e = if (code == 401 || code == 403 || msg.contains("API key", true)) "not_granted"
                            else if (code == 429) "rate_limited" else "http_$code:" + msg.take(140)
                        js("__ai($id,null,${q(e)})")
                    }
                } catch (e: Exception) {
                    js("__ai($id,null,${q("exc:" + (e.message ?: e.javaClass.simpleName).take(100))})")
                }
            }.start()
        }

        @JavascriptInterface fun askClaude(id: Int, json: String) {
            Thread {
                try {
                    val body = JSONObject(json).put("model", "claude-haiku-5-5").put("max_tokens", 400)
                    val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                    c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
                    c.setRequestProperty("content-type", "application/json")
                    c.setRequestProperty("x-api-key", prefs.getString("aikey", "") ?: "")
                    c.setRequestProperty("anthropic-version", "2023-06-01")
                    c.outputStream.use { it.write(body.toString().toByteArray()) }
                    val code = c.responseCode
                    val txt = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
                    if (code < 400) {
                        val a = JSONObject(txt).getJSONArray("content"); val sb = StringBuilder()
                        for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (o.optString("type") == "text") sb.append(o.getString("text")) }
                        js("__ai($id,${q(sb.toString())},null)")
                    } else {
                        val e = when (code) { 401, 403 -> "not_granted"; 429 -> "rate_limited"; else -> "error" }
                        js("__ai($id,null,${q(e)})")
                    }
                } catch (e: Exception) { js("__ai($id,null,'error')") }
            }.start()
        }
    }
}

class OverlayActivity : MainActivity() {
    override val overlay: Boolean = true
}
