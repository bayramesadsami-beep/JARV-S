package com.jarvis.assistant
import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.*
import android.widget.EditText
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var loaded = false
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    private fun js(s: String) = runOnUiThread { web.evaluateJavascript(s, null) }
    private fun q(s: String) = JSONObject.quote(s)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA), 1)
        tts = TextToSpeech(this) { ttsReady = it == TextToSpeech.SUCCESS; if (ttsReady) tts?.language = Locale("tr", "TR") }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) { js("__tts('start',$u)") }
            override fun onDone(u: String?) { js("__tts('end',$u)") }
            override fun onError(u: String?) { js("__tts('end',$u)") }
            override fun onStop(u: String?, i: Boolean) { js("__tts('end',$u)") }
        })
        web = WebView(this); setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) { runOnUiThread { r.grant(r.resources) } }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                startActivity(Intent(Intent.ACTION_VIEW, r.url)); return true
            }
            override fun onPageFinished(v: WebView, u: String) { loaded = true; autoListen() }
        }
        web.addJavascriptInterface(Bridge(), "J")
        val html = assets.open("index.html").bufferedReader().readText()
        web.loadDataWithBaseURL("https://jarvis.local/", html, "text/html", "utf-8", null)
        if (prefs.getString("key", "").isNullOrEmpty()) askKey()
    }

    private fun autoListen() {
        if (loaded && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            js("var b=document.getElementById('bmic');if(b.getAttribute('aria-pressed')!=='true')b.click()")
    }
    override fun onNewIntent(intent: Intent?) { super.onNewIntent(intent); autoListen() }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { autoListen() }

    private fun askKey() {
        val et = EditText(this); et.hint = "sk-ant-..."
        AlertDialog.Builder(this).setTitle("Anthropic API anahtarı")
            .setMessage("Jarvis'in yapay zekâ cevapları için gerekli. Anahtar yalnızca bu telefonda saklanır.")
            .setView(et).setCancelable(false)
            .setPositiveButton("Kaydet") { _, _ -> prefs.edit().putString("key", et.text.toString().trim()).apply() }
            .setNegativeButton("Şimdi değil", null).show()
    }

    inner class Bridge {
        @JavascriptInterface fun listen(lang: String) { runOnUiThread {
            sr?.destroy()
            sr = SpeechRecognizer.createSpeechRecognizer(this@MainActivity)
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { js("__sr('start')") }
                override fun onPartialResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) js("__sr('result',${q(t)},false)")
                }
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    if (t.isBlank()) js("__sr('error','no-speech')") else js("__sr('result',${q(t)},true)")
                    js("__sr('end')")
                }
                override fun onError(e: Int) {
                    val n = when (e) { 9 -> "not-allowed"; 6, 7 -> "no-speech"; 5, 8 -> "aborted"; else -> "network" }
                    js("__sr('error','$n')"); js("__sr('end')")
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            sr?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true))
        } }
        @JavascriptInterface fun stopListen() { runOnUiThread { sr?.stopListening() } }
        @JavascriptInterface fun speak(text: String, id: Int) { runOnUiThread {
            if (!ttsReady) js("__tts('end',$id)") else tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id.toString())
        } }
        @JavascriptInterface fun stopSpeak() { runOnUiThread { tts?.stop() } }
        @JavascriptInterface fun ask(id: Int, json: String) {
            Thread {
                try {
                    val body = JSONObject(json).put("model", "claude-haiku-5-5").put("max_tokens", 400)
                    val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                    c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
                    c.setRequestProperty("content-type", "application/json")
                    c.setRequestProperty("x-api-key", prefs.getString("key", "") ?: "")
                    c.setRequestProperty("anthropic-version", "2023-06-01")
                    c.outputStream.use { it.write(body.toString().toByteArray()) }
                    val code = c.responseCode
                    val txt = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
                    if (code < 400) {
                        val a = JSONObject(txt).getJSONArray("content"); val sb = StringBuilder()
                        for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (o.optString("type") == "text") sb.append(o.getString("text")) }
                        js("__ai($id,${q(sb.toString())},null)")
                    } else {
                        val e = when (code) { 401, 403 -> "not_granted"; 429 -> "rate_limited"; else -> "error" }
                        js("__ai($id,null,${q(e)})")
                    }
                } catch (e: Exception) { js("__ai($id,null,'error')") }
            }.start()
        }
    }
}
