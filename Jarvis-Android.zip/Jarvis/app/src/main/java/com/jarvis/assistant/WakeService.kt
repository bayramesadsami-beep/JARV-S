package com.jarvis.assistant
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

object WakeState { @Volatile var paused = false }

// Telefondaki gerçek (Google) ses tanıyıcıyı adıyla seçer; Jarvis'in kendi boş tanıyıcısını atlar.
fun pickRecognizer(c: Context): SpeechRecognizer {
    val list = c.packageManager.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
        .map { it.serviceInfo }.filter { it.packageName != c.packageName }
    val pick = list.firstOrNull { it.packageName == "com.google.android.googlequicksearchbox" }
        ?: list.firstOrNull { it.packageName.contains("google") } ?: list.firstOrNull()
    return if (pick != null) SpeechRecognizer.createSpeechRecognizer(c, ComponentName(pick.packageName, pick.name))
    else SpeechRecognizer.createSpeechRecognizer(c)
}

// Arka planda Google ses tanımasıyla "Jarvis" kelimesini bekler; duyunca alt paneli açar.
class WakeService : Service() {
    private var sr: SpeechRecognizer? = null
    private var active = false
    private var nextTry = 0L
    private val h = Handler(Looper.getMainLooper())
    private val wakeRe = Regex("\\b(?:hey+|hay+|ey+|hei)[\\s,]*(?:jarvis|çarvis|carvis|jarvıs|carvıs|harvis)\\b")
    private val unq = Runnable { unquiet() }
    private val tick = object : Runnable {
        override fun run() {
            val want = !WakeState.paused
            if (want && !active && System.currentTimeMillis() >= nextTry) startDetect()
            else if (!want && active) stopDetect()
            h.postDelayed(this, 700)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("wake", "Jarvis dinliyor", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "wake").setContentTitle("Jarvis hazır")
            .setContentText("“Hey Jarvis” diyerek çağırabilirsiniz")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        h.post(tick)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    // Tanıyıcının başlangıç/bitiş bip sesini kısa süre kısar (müzik çalıyorsa dokunmaz).
    private fun quiet(ms: Long) {
        val a = getSystemService(AUDIO_SERVICE) as AudioManager
        if (a.isMusicActive) return
        for (s in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_SYSTEM))
            try { a.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0) } catch (e: Exception) {}
        h.removeCallbacks(unq); h.postDelayed(unq, ms)
    }
    private fun unquiet() {
        val a = getSystemService(AUDIO_SERVICE) as AudioManager
        for (s in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_SYSTEM))
            try { a.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0) } catch (e: Exception) {}
    }

    private fun startDetect() { active = true; listen() }

    private fun listen() {
        if (!active) return
        quiet(1500)
        try {
            sr?.destroy()
            sr = pickRecognizer(this)
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onPartialResults(r: Bundle?) { check(r) }
                override fun onResults(r: Bundle?) { check(r); again(350) }
                override fun onEndOfSpeech() { quiet(1500) }
                override fun onError(e: Int) {
                    quiet(1500)
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopDetect(); nextTry = System.currentTimeMillis() + 60000 }
                    else again(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 350)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            sr?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true))
        } catch (e: Exception) { stopDetect(); nextTry = System.currentTimeMillis() + 15000 }
    }

    private fun again(ms: Long) {
        if (!active) return
        try { sr?.destroy() } catch (e: Exception) {}
        sr = null
        h.postDelayed({ listen() }, ms)
    }

    private fun check(r: Bundle?) {
        val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase(Locale("tr")) ?: return
        if (wakeRe.containsMatchIn(t)) wake()
    }

    private fun stopDetect() {
        active = false
        try { sr?.destroy() } catch (e: Exception) {}
        sr = null
        h.removeCallbacks(unq); unquiet()
    }

    private fun wake() {
        if (!active) return
        WakeState.paused = true
        stopDetect()
        startActivity(Intent(this, OverlayActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("assist", true))
    }

    override fun onDestroy() { h.removeCallbacks(tick); stopDetect(); super.onDestroy() }
}
