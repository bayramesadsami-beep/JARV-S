package com.jarvis.assistant
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

class JarvisService : VoiceInteractionService()

class JarvisSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = JarvisSession(this)
}

class JarvisSession(c: Context) : VoiceInteractionSession(c) {
    override fun onShow(args: Bundle?, flags: Int) {
        super.onShow(args, flags)
        val i = Intent(context, OverlayActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("assist", true)
        try { startAssistantActivity(i) } catch (e: Exception) { context.startActivity(i) }
        hide()
    }
}

// Asistan olarak seçilebilmek için gereken boş tanıyıcı; asıl ses tanıma MainActivity içinde.
class JarvisRecognition : RecognitionService() {
    override fun onStartListening(i: Intent?, cb: Callback?) { cb?.error(SpeechRecognizer.ERROR_CLIENT) }
    override fun onStopListening(cb: Callback?) {}
    override fun onCancel(cb: Callback?) {}
}
