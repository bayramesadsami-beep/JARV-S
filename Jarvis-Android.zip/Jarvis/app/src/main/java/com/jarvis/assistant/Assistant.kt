package com.jarvis.assistant
import android.app.assist.AssistContent
import android.app.assist.AssistStructure
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.view.View

// Güç tuşuyla çağrıldığında ön plandaki uygulamanın ekran metni burada saklanır.
object ScreenCtx {
    @Volatile var text = ""
    @Volatile var at = 0L
    fun fresh(): String = if (System.currentTimeMillis() - at < 180000) text else ""
}

class JarvisService : VoiceInteractionService()

class JarvisSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = JarvisSession(this)
}

class JarvisSession(c: Context) : VoiceInteractionSession(c) {
    private val h = Handler(Looper.getMainLooper())

    override fun onShow(args: Bundle?, flags: Int) {
        super.onShow(args, flags)
        ScreenCtx.text = ""; ScreenCtx.at = 0L
        val i = Intent(context, OverlayActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("assist", true)
        try { startAssistantActivity(i) } catch (e: Exception) { context.startActivity(i) }
        h.postDelayed({ hide() }, 1500)
    }

    override fun onHandleAssist(data: Bundle?, structure: AssistStructure?, content: AssistContent?) {
        super.onHandleAssist(data, structure, content)
        if (structure == null) return
        val sb = StringBuilder()
        for (k in 0 until structure.windowNodeCount) walk(structure.getWindowNodeAt(k).rootViewNode, sb)
        ScreenCtx.text = sb.toString().replace(Regex("\\s+"), " ").trim()
        ScreenCtx.at = System.currentTimeMillis()
    }

    private fun walk(n: AssistStructure.ViewNode, sb: StringBuilder) {
        if (n.visibility == View.VISIBLE) {
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (!t.isNullOrEmpty()) sb.append(t).append(". ")
        }
        for (i in 0 until n.childCount) walk(n.getChildAt(i), sb)
    }
}

// Asistan olarak seçilebilmek için gereken boş tanıyıcı; asıl ses tanıma MainActivity içinde.
class JarvisRecognition : RecognitionService() {
    override fun onStartListening(i: Intent?, cb: Callback?) { cb?.error(SpeechRecognizer.ERROR_CLIENT) }
    override fun onStopListening(cb: Callback?) {}
    override fun onCancel(cb: Callback?) {}
}
